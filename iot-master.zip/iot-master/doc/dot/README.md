##System Struct##
To make the Struct just Run,if you install the graphviz
    
    make    

and

    make clean
    
to remove the picture